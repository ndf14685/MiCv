// const studentsList = [
//   1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27
// ];

const studentsList = [];

const questionsList = [
  '¿En qué deporte creés que le podrías ganar a tu mentor/a?',
  '¿Cual es tu gusto de helado preferido? Fundamente su respuesta.',
  '¿Cuál fue la mejor película/serie que viste? (o libro que leíste)',
  '¿Qué es lo que mejor sabés cocinar?',
  'Si no vivieras en Buenos Aires, ¿dónde te gustaría vivir?',
  'Si tuvieras que elegir una sola comida para comer por el resto de tu vida, ¿cuál sería?',
  '¿Preferís el verano o el invierno? ¿Por qué?',
  'Si tuvieras la plata para poner una fábrica o un negocio, ¿de qué sería?',
  '¿A favor o en contra de las montañas rusas? ¿Por qué?',
  '¿Quién era tu ídolo/a de la infancia? ¿Por qué?',
  'Si pudieras cambiar algo en el mundo, ¿qué cambiarías?',
  'Si fueras un/a superhéroe, ¿cuál sería tu superpoder?',
  '¿A quién llevarías a una isla desierta?',
  '¿Preferís el campo, las montañas, la ciudad o la playa?',
  'Si tuvieses que convertirte en un animal, ¿cuál elegirías? Fundamente.',
  '¿Si pudieras viajar a cualquier época (pasado o futuro), cuándo elegirías?',
  '¿Cuál es la mejor marca de alfajor? Fundamente.',
  '¿Dónde serían tus vacaciones ideales?',
  'Si mañana te despertás y sos invisible, ¿qué es lo primero que harías?',
  '¿Preferís leer ficción o no ficción?',
  'Si la plata y el tiempo no importaran, ¿de qué te disfrazarías en una fiesta de disfraces?',
  'Si pudieras conocer a cualquier persona de la historia, ¿a quién elegirías?',
  'Si tuvieses que tirarte en una pileta repleta de algo, ¿de qué sería?',
  'Si pudieras tener flujo ilimitado de una sola cosa, ¿qué elegirías?',
  'Qué decías cuando eras chico/a y te preguntaban: ¿qué querés ser de grande?',
  '¿Cual es tu película favorita de Star Wars?'
];
